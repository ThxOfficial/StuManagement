from flask import Flask, request, json
import pymysql
import random

app = Flask(__name__)

@app.route('/captcha',methods=['GET','POST'])
def captcha():
    num=random.randint(1,40)
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql="SELECT * FROM CAPTCHA WHERE NUM='"+str(num)+"'"
    cursor.execute(sql)
    res=cursor.fetchone()
    return json.dumps(res)


rigid='114514'
@app.route('/login', methods=['GET', 'POST'])
def login():  # put application's code here
    exist = 'no'
    id0 = request.values.get("id")
    pswd0 = request.values.get("password")
    id = 'no'
    pswd = 'no'
    if id0 and pswd0:
        id1=id0
        pswd1=pswd0
        print(id0, pswd0)
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "SELECT PSWD FROM SUSER WHERE ID = '" + id1 + "'"
        print(sql)
        cursor.execute(sql)
        check = cursor.fetchall()

        if check:
            print(check[0][0])
            if (check[0][0] == pswd1):
                pswd = 'yes'
            exist = 'yes'
            id = 'yes'
        # exist = 'yes'#貌似有问题
    res = (id, exist, pswd)
    print(res[0], res[1], res[2])
    return json.dumps(res)



@app.route('/logint', methods=['GET', 'POST'])
def logint():
    exist = 'no'
    id0 = request.values.get("id")
    pswd0 = request.values.get("password")
    id = 'no'
    pswd = 'no'
    if id0 and pswd0:
        id1 = id0
        pswd1 = pswd0
        print(id0, pswd0)
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "SELECT PSWD FROM TUSER WHERE ID = '" + id1 + "'"
        print(sql)
        cursor.execute(sql)
        check = cursor.fetchall()

        if check:
            print(check[0][0])
            if (check[0][0] == pswd1):
                pswd = 'yes'
            exist = 'yes'
            id = 'yes'
        # exist = 'yes'#貌似有问题
    res = (id, exist, pswd)
    print(res[0], res[1], res[2])
    return json.dumps(res)

@app.route("/sid",methods=['GET','POST'])
def stu_id():
    exist = 'yes'
    right = 'no'
    id = request.values.get("id")
    print(id)
    num = 0
    els = 0
    for index in range(len(id)):
        if id[index] >= '0' and id[index] <= '9':
            num += 1
        else:
            els += 1
    if len(id) == 12:
        if num >0 and els == 0:
            right = 'yes'
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "SELECT ID FROM SUSER WHERE ID = '" + id + "'"
    print(sql)
    cursor.execute(sql)
    check = cursor.fetchall()
    # checkpwd = check[0][0]
    print(check)
    if len(check) == 0:
        print("正确")
        exist='no'
    res = (exist, right)
    global rigid
    rigid=id
    print(rigid)
    return json.dumps(res)

@app.route('/tid',methods=['GET','POST'])
def tea_id():
    exist = 'yes'
    right = 'no'
    id = request.values.get("id")
    print(id)
    num = 0
    els = 0
    for index in range(len(id)):
        if id[index] >= '0' and id[index] <= '9':
            num += 1
        else:
            els += 1
    if len(id) == 12:
        if num > 0 and els == 0:
            right = 'yes'
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "SELECT ID FROM TUSER WHERE ID = '" + id + "'"
    print(sql)
    cursor.execute(sql)
    check = cursor.fetchall()
    # checkpwd = check[0][0]
    print(check)
    if len(check) == 0:
        print("正确")
        exist = 'no'
    res = (exist, right)
    global rigid
    rigid = id
    return json.dumps(res)

@app.route('/spswd',methods=['GET','POST'])
def spswd():
    pswd = request.values.get("pswd")
    num = 0
    chrbig = 0
    sym = 0
    chrsmall = 0
    short = 'short'
    right = 'no'
    # 密码需要大于8位
    if len(pswd) >= 8:
        short = 'long'
        for index in range(len(pswd)):
            if pswd[index] >= 'a' and pswd[index] <= 'z':
                chrsmall += 1
            elif pswd[index] >= '0' and pswd[index] <= '9':
                num += 1
            elif pswd[index] >= 'A' and pswd[index] <= 'Z':
                chrbig += 1
            elif pswd[index] == '!' or pswd[index] == '?' or pswd[index] == '@':
                sym += 1
    print(chrsmall,num,chrbig,sym,short)
    if num and chrbig and chrsmall and sym:
        right='yes'
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "INSERT INTO SUSER VALUES('"+rigid+"','"+pswd+"');"
        print(sql)
        cursor.execute(sql)
        #check = cursor.fetchall()
        '''conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()'''
        sql = "INSERT INTO STUINFO(ID) VALUES('" + rigid + "');"
        print(sql)
        cursor.execute(sql)
    res = (short, right)
    return json.dumps(res)





@app.route('/tpswd',methods=['GET','POST'])
def tpswd():
    pswd = request.values.get("pswd")
    num = 0
    chrbig = 0
    sym = 0
    chrsmall = 0
    short = 'short'
    right = 'no'
    # 密码需要大于8位
    if len(pswd) >= 8:
        short = 'long'
        for index in range(len(pswd)):
            if pswd[index] >= 'a' and pswd[index] <= 'z':
                chrsmall += 1
            elif pswd[index] >= '0' and pswd[index] <= '9':
                num += 1
            elif pswd[index] >= 'A' and pswd[index] <= 'Z':
                chrbig += 1
            elif pswd[index] == '!' or pswd[index] == '?' or pswd[index] == '@':
                sym += 1
    print(chrsmall,num,chrbig,sym,short)
    if num and chrbig and chrsmall and sym:
        right='yes'
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "INSERT INTO TUSER VALUES('"+rigid+"','"+pswd+"');"
        print(sql)
        cursor.execute(sql)
        #check = cursor.fetchall()
        sql = "INSERT INTO ARRINFO(ID) VALUES('" + rigid + "');"
        print(sql)
        cursor.execute(sql)
    res = (short, right)
    return json.dumps(res)

@app.route('/sctr',methods=['GET','POST'])
def sctr():
    id=request.values.get("id")
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "SELECT * FROM STUINFO WHERE ID = '" + id + "'"
    print(sql)
    cursor.execute(sql)
    res = cursor.fetchall()
    print(res)
    return json.dumps(res)
@app.route('/tctr',methods=['GET','POST'])
def tctr():
    id=request.values.get("id")
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "SELECT * FROM ARRINFO WHERE ID = '" + id + "'"
    print(sql)
    cursor.execute(sql)
    res = cursor.fetchall()
    print(res)
    return json.dumps(res)

@app.route('/sinfocg',methods=['GET','POST'])
def sinfocg():
    id = request.values.get("id")
    nkname = request.values.get("nkname")
    name = request.values.get("name")
    sex = request.values.get("sex")
    sig = request.values.get("sig")
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    if(nkname):
        sql = "UPDATE STUINFO SET NKNAME='"+ nkname +"' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    if (name):
        sql = "UPDATE STUINFO SET NAME='" + name + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    if (sex):
        sql = "UPDATE STUINFO SET SEX='" + sex + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    if (sig):
        sql = "UPDATE STUINFO SET SIG='" + sig + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    return 'yes'

@app.route('/tinfocg',methods=['GET','POST'])
def tinfocg():
    id = request.values.get("id")
    name = request.values.get("name")
    sex = request.values.get("sex")
    sig = request.values.get("sig")
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    if (name):
        sql = "UPDATE ARRINFO SET NAME='" + name + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    if (sex):
        sql = "UPDATE ARRINFO SET SEX='" + sex + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    if (sig):
        sql = "UPDATE ARRINFO SET SIG='" + sig + "' WHERE ID = '" + id + "'"
        cursor.execute(sql)
    return 'yes'

@app.route('/course',methods=['GET','POST'])
def course():
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT * FROM COURSE"
    cursor.execute(sql)
    res = cursor.fetchall()
    print(res)
    return json.dumps(res)

@app.route('/courcg',methods=['GET','POST'])
def courcg():
    cid = request.values.get("cid")
    print(cid)
    return '0'

@app.route('/courdel',methods=['GET','POST'])
def courdel():
    cid = request.values.get("cid")
    print(cid)
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "DELETE FROM COURSE WHERE CID = '" + cid + "'"
    cursor.execute(sql)
    return '0'

@app.route('/teapiccg',methods=['GET','POST'])
def teapiccg():
    pic = request.files.get('pic')
    tid = request.form.get("tid")
    print(tid)
    if pic is not None:
        path= '../images/teacenter/' + tid + '.png'
        picpath='/images/teacenter/'+tid+'.png'
        pic.save(path)
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "UPDATE ARRINFO SET PIC='" + picpath + "' WHERE ID = '" + tid + "'"
        cursor.execute(sql)
        return "success"
    return "fail"

@app.route('/coursecg',methods=['GET','POST'])
def coursecg():
    id = request.values.get("cid")
    name = request.values.get("name")
    tm = request.values.get("tm")
    score = request.values.get("score")
    print("id"+id)
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    if (name):
        sql = "UPDATE COURSE SET NAME='" + name + "' WHERE CID = '" + id + "'"
        cursor.execute(sql)
    if (tm):
        sql = "UPDATE COURSE SET TM=" + tm + " WHERE CID = '" + id + "'"
        cursor.execute(sql)
    if (score):
        sql = "UPDATE COURSE SET SCORE=" + score + " WHERE CID = '" + id + "'"
        cursor.execute(sql)
    return 'yes'

@app.route('/coursefd',methods=['GET','POST'])
def coursefd():
    id = request.values.get("id")
    conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                           charset='utf8', autocommit=True)
    cursor = conn.cursor()
    sql = "SELECT * FROM COURSE WHERE CID = '" + id + "'"
    cursor.execute(sql)
    res = cursor.fetchone()
    return json.dumps(res)

@app.route('/coursepiccg',methods=['GET','POST'])
def coursepiccg():
    pic = request.files.get('pic')
    print(pic)
    cid = request.form.get("cid")
    print(cid)
    if pic is not None:
        path='../images/course/'+cid+'.png'
        picpath='/images/course/'+cid+'.png'
        pic.save(path)
        conn = pymysql.connect(host='localhost', user='root', password='thx1011', database='STUSYS',
                               charset='utf8', autocommit=True)
        cursor = conn.cursor()
        sql = "UPDATE COURSE SET PIC='" + picpath + "' WHERE CID = '" + cid + "'"
        cursor.execute(sql)
        return "success"
    return "fail"

if __name__ == '__main__':
    app.run()
